package ch07.exam06.pack1;

public class A {
		 protected int field;
		
		
		protected A(){}
		
		
		 protected void method(){}
}
