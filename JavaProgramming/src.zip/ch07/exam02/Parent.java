package ch07.exam02;

public class Parent {
	
	//Field
	String lastName;
	//Constructor
	Parent(String lastName){
		this.lastName=lastName;
	}
	//Method
	void sound(){
		System.out.println("����");
	}
}
