package ch07.exam05;

public final class Calculator {

}
