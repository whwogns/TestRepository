package ch07.exam05;

public class Computer {
	final int plus(int x, int y){
	 return x+y;
}
	
	double circleArea(double r){
	return 2.14159*r*r;
	}
}
