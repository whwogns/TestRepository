package ch07.exam09;

public class Tire {
//Field
//Constructor
//Method
	void roll(){}
}
