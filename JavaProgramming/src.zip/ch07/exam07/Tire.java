package ch07.exam07;

public class Tire {
//Field
//Constructor
//Method
	void roll(){}
}
