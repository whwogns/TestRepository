package Homework.exam07_5;

public class Tire {
	
	void roll(){
		
		

	}

}
