package Homework.exam07_3;

public class Tire {
	void roll(){
		
	}

}
