package Homework.exam07_8;

public class Tire {
	
	void roll(){
		
	}

}
