package Homework.exam07_4;

public class Tire {
	
	void roll(){
		
	}

}
