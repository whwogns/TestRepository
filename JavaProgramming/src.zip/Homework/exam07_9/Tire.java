package Homework.exam07_9;

public class Tire {
	
	void roll(){
		
	}

}
