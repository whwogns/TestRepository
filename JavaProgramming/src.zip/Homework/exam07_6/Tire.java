package Homework.exam07_6;

public class Tire {
	
	void roll(){
		
	}

}
