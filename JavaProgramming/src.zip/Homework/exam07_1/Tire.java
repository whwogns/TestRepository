package Homework.exam07_1;

public class Tire {
	void roll(){
		
	}

}
