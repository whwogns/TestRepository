package Homework.exam07_0;

public class Tire {
	
	void roll(){
		System.out.println("");
	}

}
