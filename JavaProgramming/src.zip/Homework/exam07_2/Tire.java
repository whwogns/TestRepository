package Homework.exam07_2;

public class Tire {
	void roll(){
		
	}
}
