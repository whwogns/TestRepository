package Homework.exam07_7;

public class Tire {
	
	void roll(){
		
	}

}
