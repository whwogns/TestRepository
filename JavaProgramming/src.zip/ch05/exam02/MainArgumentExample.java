package ch05.exam02;

public class MainArgumentExample {

	public static void main(String[] args) {
		System.out.println(args.length);
		
		
	//ch05.exam02.MainArgumentExample;
	}
}
