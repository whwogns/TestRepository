package ch05.exam02;

public class ArrayExample01 {
	public static void main(String[] args){
		
		double[] v1 = new double[5];
		
		for(int i=0; i<v1.length; i++){
			System.out.println("v1[" +i+"]:" + v1[i]);
		}
			 
	}
}

