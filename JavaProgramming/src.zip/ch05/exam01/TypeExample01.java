package ch05.exam01;

public class TypeExample01 {
	public static void main(String[] args){
		System.out.println("main() method run...");
		//�⺻Ÿ��
		byte v1 = 10;
		char v2 = 'A';
		short v3 = 10;
		int v4 = 10;
		long v5 = 10L;
		
		float v6 = 10.0f;
		double v7 = 10.0;
		
		boolean v8 = true;
		
		//����Ÿ��
		String name = "Java";
		int[] scores = {90,80,85};
		
	}
}
