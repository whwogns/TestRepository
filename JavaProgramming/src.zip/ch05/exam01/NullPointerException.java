package ch05.exam01;

public class NullPointerException {
	public static void main(String[] args) {
		
		String name = null;
		name="������";
		int num=3;
		System.out.println(name);
		System.out.println(num);
		System.out.println(name.charAt(0));;
	
	}

}
