package ch06.exam08;

public class CalculatorExample {

	public static void main(String[] args) {
	new calculator();
	new calculator();
	new calculator();
		
	}

}
