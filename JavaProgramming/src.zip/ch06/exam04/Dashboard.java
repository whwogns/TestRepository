package ch06.exam04;

public class Dashboard {
//Field
	//constructor
	//method
	void display (int speed){
		System.out.println("�뽬����:"+speed);
	}
}
