package ch06.Exam05;

public class Member {
//Field
	String name;
	int age;
	//Constructor
	Member(String name, int age) {
		this.name=name;
		this.age=age;
	}
	//Method
}
