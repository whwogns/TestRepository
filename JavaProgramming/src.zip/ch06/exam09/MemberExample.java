package ch06.exam09;

public class MemberExample {

	public static void main(String[] args) {
		Member member = new Member("ȫ�浿","111111-1234567");
		member.name="���ڹ�";
		//member.ssn = "222222-1111111";
				

	}

}
