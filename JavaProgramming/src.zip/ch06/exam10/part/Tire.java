package ch06.exam10.part;

public class Tire {

}
