package ch09.exam07;

public class A {
	//Field
	//Constructor
	//Method
	
	
	//Nested Class
	static class B{
		void bMethod(){}
	}
	//Nested Interface
	interface C{
		void cMethod();
	}
}
