package ch09.exam06;

public class A {
	
	//Field
	//Constructor
	//Method
	
	//Nested Interface
	interface B{
		void method();
	}//

}
