package study.CCEE;

public class Cat extends Animal{

}
