package study.CCEE;

public class Animal {

}
