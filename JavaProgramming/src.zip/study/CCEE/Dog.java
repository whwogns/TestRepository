package study.CCEE;

public class Dog extends Animal{

}
