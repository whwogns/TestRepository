package ch14.exam06;

public class Member {

	private String mid;
	private String mname;
	
	public Member(String mid, String mname){
		this.mid = mid;
		this.mname = mname;
	}
}
