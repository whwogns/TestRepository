package ch14.exam06;

public interface FunctionalInterface {
	public Member createMember(String mid, String mname);
}
