package ch14.exam04;

public class Calculator {
	static int staticSum (int a, int b){
		return a+b;
	}
	static int staticMulti (int a, int b){
		return a*b;
	}
	
	public int minus(int a, int b){
		return a-b;
	}
}
