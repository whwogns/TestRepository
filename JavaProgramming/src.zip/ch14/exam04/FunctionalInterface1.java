package ch14.exam04;

public interface FunctionalInterface1 {
	public int method(int a, int b);
}
