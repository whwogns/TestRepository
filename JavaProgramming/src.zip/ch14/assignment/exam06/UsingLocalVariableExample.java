package ch14.assignment.exam06;

public class UsingLocalVariableExample {

	public static void main(String[] args) {
		UsingLocalVariable ulv = new UsingLocalVariable();
		ulv.method(20);
		

	}

}
