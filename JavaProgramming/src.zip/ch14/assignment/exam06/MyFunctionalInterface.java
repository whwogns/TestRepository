package ch14.assignment.exam06;

public interface MyFunctionalInterface {
	public void method();
}
