package ch14.assignment.exam03;

public interface MyFunctionalInterface {
	public int method(int x, int y);
}
