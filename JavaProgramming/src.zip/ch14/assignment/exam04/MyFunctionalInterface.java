package ch14.assignment.exam04;

public interface MyFunctionalInterface {
	public int method(int x, int y);

}
