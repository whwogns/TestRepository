package ch14.assignment.exam02;
@FunctionalInterface
public interface MyFunctionalInterface {
	public void method(int x);
}
