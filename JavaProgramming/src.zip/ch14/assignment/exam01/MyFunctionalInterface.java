package ch14.assignment.exam01;

@FunctionalInterface
public interface MyFunctionalInterface {
	public void method();
	
}

