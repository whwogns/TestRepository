package ch14.assignment.exam05;

public interface MyFunctionalInterface {
	public void method();
}
