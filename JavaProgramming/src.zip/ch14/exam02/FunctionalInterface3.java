package ch14.exam02;

public interface FunctionalInterface3 {
	public void method(int a, int b);
}
