package ch14.exam02;

public interface FunctionalInterface4 {
	public int method(int a, int b);
}
