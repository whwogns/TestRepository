package ch14.exam02;

public interface FunctionalInterface2 {
	public void method(int a);
}
