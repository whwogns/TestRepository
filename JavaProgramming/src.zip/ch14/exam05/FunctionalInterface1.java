package ch14.exam05;

public interface FunctionalInterface1 {
	public boolean method(String a, String b);
}
