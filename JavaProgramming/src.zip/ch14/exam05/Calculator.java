package ch14.exam05;

public class Calculator {
	public boolean equals(int a, int b){
		if(a==b) return true;
		else return false;
	}
}
