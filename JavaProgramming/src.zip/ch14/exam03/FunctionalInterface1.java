package ch14.exam03;

public interface FunctionalInterface1 {
	public void method();
}
