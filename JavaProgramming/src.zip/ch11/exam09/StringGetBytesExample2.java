package ch11.exam09;

public class StringGetBytesExample2 {

	public static void main(String[] args) {
		
	}

}
