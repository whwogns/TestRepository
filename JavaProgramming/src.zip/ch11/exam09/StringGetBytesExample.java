package ch11.exam09;

public class StringGetBytesExample {

	public static void main(String[] args) {
		String str = "�ȳ��ϼ���";
		
		byte[] bytes1 = str.getBytes();
		System.out.println("bytes1.length : "+byte1.length);
		String str1 = new String(bytes1);
		System.out.println("bytes1->String:"+str1);
		
		try{
			byte[] bytes2 =
		}
	}

}
