package ch10.exam01;

public class Animal {

}
