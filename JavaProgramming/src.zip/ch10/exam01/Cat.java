package ch10.exam01;

public class Cat extends Animal{

}
