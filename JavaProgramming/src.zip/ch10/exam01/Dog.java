package ch10.exam01;

public class Dog extends Animal{

}
